archi1=open("datos.txt","w",encoding="utf-8")
archi1.write("Primera linea\n")
archi1.write("Segunda linea\n")
archi1.write("Tercera linea\n")
archi1.write("♪") #Alt+269
archi1.close()