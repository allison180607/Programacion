#Leer el contenido de texto ´datos.txt´ linea a linea con WHILE
archi1=open("datos.txt","r")
linea=archi1.readline()
while linea!='':
    print(linea, end='')
    linea=archi1.readline()
archi1.close()

#Leer el contenido del archivo del texto 'datos.txt' linea por linea con FOR
archi1=open("datos.txt","r")
for linea in archi1:
    print(linea, end='')
archi1.close()