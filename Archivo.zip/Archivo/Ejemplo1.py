#Ejemplificando creacion de archivos en Python

#Declarar un objeto de tipo de archivo
archi1=open("datos.txt","w")
archi1.write("Primera linea\n")
archi1.write("Segunda linea\n")
archi1.write("Tercera linea\n")
archi1.close()
print("Finsl del programa")